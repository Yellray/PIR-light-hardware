*PADS-LIBRARY-PART-TYPES-V9*

1N5819HWQ-7-F SOD3716X145N I DIO 7 1 0 0 0
TIMESTAMP 2026.06.20.14.32.54
"Mouser Part Number" 621-1N5819HWQ-7-F
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Diodes-Incorporated/1N5819HWQ-7-F?qs=gZXFycFWdAPDr8BmsK1ygg%3D%3D
"Manufacturer_Name" Diodes Incorporated
"Manufacturer_Part_Number" 1N5819HWQ-7-F
"Description" Schottky Diode 40 V 1A Surface Mount SOD-123
"Datasheet Link" https://www.diodes.com//assets/Datasheets/1N5819HW.pdf
"Geometry.Height" 1.45mm
GATE 1 2 0
1N5819HWQ-7-F
1 0 U K
2 0 U A

*END*
*REMARK* SamacSys ECAD Model
1827197/1585334/2.50/2/2/Schottky Diode
